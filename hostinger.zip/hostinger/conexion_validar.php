<?php
$servidor = "localhost";
$usuario = "root";
$password = "";
$db = "calssic_street";

$conexion=mysqli_connect("localhost","root","","classic");




?>