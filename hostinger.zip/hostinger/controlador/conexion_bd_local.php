<?php 
$conexion=mysqli_connect("localhost","root","","classic_street"); ?>