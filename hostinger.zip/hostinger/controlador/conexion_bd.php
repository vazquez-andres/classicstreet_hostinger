<?php 
$conexion=mysqli_connect("localhost","u119512436_andres","Andresflash100","u119512436_classic_street"); ?>