-- MariaDB dump 10.19  Distrib 10.5.12-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: u119512436_classic_street
-- ------------------------------------------------------
-- Server version	10.5.12-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cargo`
--

DROP TABLE IF EXISTS `cargo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cargo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cargo` varchar(256) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cargo`
--

LOCK TABLES `cargo` WRITE;
/*!40000 ALTER TABLE `cargo` DISABLE KEYS */;
INSERT INTO `cargo` VALUES (1,'administrador'),(2,'ventas');
/*!40000 ALTER TABLE `cargo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock`
--

DROP TABLE IF EXISTS `stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `producto` varchar(256) NOT NULL,
  `descripcion` varchar(256) NOT NULL,
  `cantidad` varchar(256) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock`
--

LOCK TABLES `stock` WRITE;
/*!40000 ALTER TABLE `stock` DISABLE KEYS */;
INSERT INTO `stock` VALUES (1,'Pomada','pomada para estilizar el cabello','12'),(3,'Minoxidil','Tratamiento para el crecimiento de vello','3'),(10,'mascarilla','mascarilla de carbon activo','5'),(11,'corte','corte de caballero','--'),(14,'Delineado de Ceja','Delineado de Ceja','--'),(15,'Delineado de Barba','Delineado de Barba','--'),(16,'After Shave','After Shave 250ml','9');
/*!40000 ALTER TABLE `stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(256) NOT NULL,
  `usuario` varchar(256) NOT NULL,
  `password` varchar(256) NOT NULL,
  `id_cargo` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_cargo` (`id_cargo`),
  CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`id_cargo`) REFERENCES `cargo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'Andres','Andres','admin',1),(10,'Zarate','zarate','1234567890',2);
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ventas`
--

DROP TABLE IF EXISTS `ventas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ventas` (
  `id_venta` int(11) NOT NULL AUTO_INCREMENT,
  `producto` varchar(256) NOT NULL,
  `precio` float NOT NULL,
  `nombre_vendedor` varchar(256) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `fecha` varchar(256) NOT NULL,
  PRIMARY KEY (`id_venta`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ventas`
--

LOCK TABLES `ventas` WRITE;
/*!40000 ALTER TABLE `ventas` DISABLE KEYS */;
INSERT INTO `ventas` VALUES (1,'corte',140,'Zarate',1,'07-19-2022 01:00:31 pm'),(2,'corte',100,'Zarate',1,'07-19-2022 01:00:35 pm'),(3,'corte',100,'Zarate',1,'07-19-2022 01:00:36 pm'),(4,'corte',100,'Zarate',1,'07-19-2022 01:00:37 pm'),(5,'corte',100,'Zarate',1,'07-19-2022 01:00:39 pm'),(6,'corte',100,'Zarate',1,'07-19-2022 01:00:40 pm'),(7,'corte',100,'Zarate',1,'07-19-2022 01:00:41 pm'),(8,'corte',100,'Zarate',1,'07-19-2022 04:11:05 pm'),(9,'corte',100,'Zarate',1,'07-19-2022 04:11:05 pm'),(10,'corte',100,'Zarate',1,'07-19-2022 04:11:12 pm'),(11,'corte',100,'Zarate',1,'07-19-2022 06:32:54 pm'),(12,'corte',100,'Zarate',1,'07-19-2022 06:32:55 pm'),(13,'corte',100,'Zarate',1,'07-19-2022 06:32:56 pm'),(15,'corte',100,'Zarate',1,'07-20-2022 04:42:22 pm'),(16,'corte',100,'Zarate',1,'07-20-2022 04:42:22 pm'),(17,'corte',100,'Zarate',1,'07-20-2022 06:23:43 pm'),(18,'corte',100,'Zarate',1,'07-20-2022 06:23:44 pm'),(19,'corte',100,'Zarate',1,'07-20-2022 07:30:27 pm'),(20,'corte',100,'Zarate',1,'07-20-2022 07:30:28 pm'),(22,'corte',100,'Zarate',1,'07-21-2022 04:41:45 pm'),(23,'corte',100,'Zarate',1,'07-21-2022 04:41:46 pm'),(24,'corte',100,'Zarate',1,'07-21-2022 05:41:24 pm'),(25,'corte',100,'Zarate',1,'07-22-2022 01:10:41 pm'),(26,'corte',100,'Zarate',1,'07-22-2022 03:09:56 pm'),(27,'corte',100,'Zarate',1,'07-22-2022 03:09:56 pm'),(28,'corte',100,'Zarate',1,'07-22-2022 04:31:38 pm'),(29,'corte',100,'Zarate',1,'07-23-2022 01:56:51 pm'),(30,'corte',100,'Zarate',1,'07-23-2022 01:56:51 pm'),(31,'corte',100,'Zarate',1,'07-23-2022 01:56:52 pm'),(32,'corte',100,'Zarate',1,'07-23-2022 01:56:53 pm'),(33,'corte',100,'Zarate',1,'07-23-2022 03:57:18 pm'),(34,'corte',100,'Zarate',1,'07-23-2022 03:57:26 pm'),(35,'corte',100,'Zarate',1,'07-23-2022 03:57:27 pm'),(36,'corte',100,'Zarate',1,'07-23-2022 03:57:28 pm'),(37,'corte',100,'Zarate',1,'07-23-2022 05:22:35 pm');
/*!40000 ALTER TABLE `ventas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-25  5:07:31
